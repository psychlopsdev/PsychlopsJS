﻿Psychlops.Util.Screenlock = true;
Psychlops.File.saveToLocalFile = true;
Psychlops.File.saveToIndexDB = true;
Psychlops.File.targetStorage = sessionStorage;
Psychlops.File.saveToServer = false;
Psychlops.File.ServerURL = "";
Psychlops.File.saveToOneDrive = false;
